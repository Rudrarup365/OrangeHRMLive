package OrangeHRMLiveAutomation1.OrangeHRMLive1;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scenario001Test {

    public static void main(String[] arg) {

        WebDriver driver = new ChromeDriver();
        driver.manage().deleteAllCookies();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // Create instances of page objects
        LoginPage loginPage = new LoginPage(driver);
        DashboardPage dashboardPage = new DashboardPage(driver);
        AdminPage adminPage = new AdminPage(driver);

        // Navigate to the login page
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

        // Verify login page
        System.out.println(loginPage.getLoginPageTitle());
        if (loginPage.isLoginImageDisplayed()) {
            System.out.println("Image Validated for Login page");
        }

        // Extract and enter usernme/password
        String usernamedata = loginPage.getUsernameFromHint();
        String passworddata = loginPage.getPasswordFromHint();
        System.out.println("Extracted username: " + usernamedata);
        System.out.println("Extracted password: " + passworddata);
        loginPage.enterUsername(usernamedata);
        loginPage.enterPassword(passworddata);
        loginPage.clickLoginButton();

        // Verify dashboard page
        if (dashboardPage.isDashboardPage()) {
            System.out.println("Verify Dashboard page");
        }

        // Click on the Admin tab
        dashboardPage.clickAdminTab();

        // Verify admin page
        if (adminPage.isAdminPage()) {
            System.out.println("Verify Admin page");
        }

        // Extract and delete data
        String placeHolder1 = adminPage.getDataText();
        adminPage.clickDeleteButton();
        adminPage.confirmDelete();

        // Verify if data is deleted
        String placeHolder2 = adminPage.getDataText();
        if (!placeHolder1.equals(placeHolder2)) {
            System.out.println("Data deleted successfully");
        }

        driver.quit();
    }
}
