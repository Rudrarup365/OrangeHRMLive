package OrangeHRMLiveAutomation1.OrangeHRMLive1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    WebDriver driver;

    // Locators
    By usernameField = By.name("username");
    By passwordField = By.name("password");
    By loginButton = By.xpath("//button[@type='submit']");
    By loginImage = By.xpath("//img[contains(@alt,'company-branding')]");
    By extractedUsernameText = By.xpath("//p[1]");
    By extractedPasswordText = By.xpath("//p[2]");

    // Constructor
    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    // Methods
    public String getLoginPageTitle() {
        return driver.getTitle();
    }

    public boolean isLoginImageDisplayed() {
        return driver.findElement(loginImage).isDisplayed();
    }

    public String getUsernameFromHint() {
        String usernameText = driver.findElement(extractedUsernameText).getText();
        return usernameText.split(" : ")[1];//split and extract username
    }

    public String getPasswordFromHint() {
        String passwordText = driver.findElement(extractedPasswordText).getText();
        return passwordText.split(" : ")[1];//split and extract password
    }

    public void enterUsername(String username) {
        driver.findElement(usernameField).sendKeys(username);
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).sendKeys(password);
    }

    public void clickLoginButton() {
        driver.findElement(loginButton).click();
    }
}