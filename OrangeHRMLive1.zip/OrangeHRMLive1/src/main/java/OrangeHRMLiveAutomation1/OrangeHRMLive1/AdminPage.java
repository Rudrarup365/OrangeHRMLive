package OrangeHRMLiveAutomation1.OrangeHRMLive1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AdminPage {

    WebDriver driver;

    // Locators
    By dataText = By.xpath("//*[@id='app']/div[1]/div[2]/div[2]/div/div[2]/div[3]/div/div[2]/div[2]");
    By deleteButton = By.xpath("//*[@id='app']/div[1]/div[2]/div[2]/div/div[2]/div[3]/div/div[2]/div[2]/div/div[6]/div/button[1]");
    By confirmDeleteButton = By.xpath("//*[@id='app']/div[3]/div/div/div/div[3]/button[2]");

    // Constructor
    public AdminPage(WebDriver driver) {
        this.driver = driver;
    }

    // Methods
    public String getDataText() {
        return driver.findElement(dataText).getText();
    }

    public void clickDeleteButton() {
        driver.findElement(deleteButton).click();
    }

    public void confirmDelete() {
        driver.findElement(confirmDeleteButton).click();
    }

    public boolean isAdminPage() {
        return driver.getCurrentUrl().contains("admin");
    }
}